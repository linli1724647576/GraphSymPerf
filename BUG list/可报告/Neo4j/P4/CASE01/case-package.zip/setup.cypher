CREATE INDEX gsp_cost_lookup IF NOT EXISTS FOR (n:GspAnchor) ON (n.uid);

CREATE (:GspAnchor {uid: 1, keep: false});

CREATE (:GspAnchor {uid: 2, keep: true})-[:GSP_EXPAND]->(:GspLeaf {uid: 3, mark: true});

MATCH (u:GspAnchor {uid: 1}) UNWIND range(1, 400000) AS i CREATE (u)-[:GSP_EXPAND]->(:GspLeaf {uid: 895440 + i, mark: false});

MATCH (u:GspAnchor) WHERE coalesce(u.keep, false) = true MATCH (u)-[:GSP_EXPAND]->(v:GspLeaf) CREATE (u)-[:GSP_REFERENCE]->(v);
